# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the bin/rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: "Star Wars" }, { name: "Lord of the Rings" }])
#   Character.create(name: "Luke", movie: movies.first)

#Users
donte = User.create!(
    firstname: 'Donte',
    lastname: 'Mitchell',
    username: 'BruiseIgnio',
    email: 'dkmtchl3@memphis.edu',
    password: 'O0FTh%s'
)

bob = User.create!(
    firstname: 'Bob',
    lastname: 'Doe',
    username: 'Bobby',
    email:    'bob@email.com',
    password: 'password'
)

alice = User.create!(
    firstname: 'Alice',
    lastname: 'Summers',
    username: 'Aly',
  email:    'alice@email.com',
  password: 'password'
)

#Interns
Intern.create!(
    biography: 'My name is Jeffery and I am searching for a software engineering internship in the Midwest.',
    experience: 'Six years as an intern at Fedex in Memphis',
    field: 'Software Engineering',
    gpa: 3.59,
    readytowork: true,
    skill: 'Python, Ruby on Rails',
    creator: donte
)

Intern.create!(
    biography: 'My name is Andre and I am searching for a game design internship anywhere in the United States.',
    experience: 'Three years as an intern at Amazon in Memphis',
    field: 'Game design',
    gpa: 4.12,
    readytowork: true,
    skill: 'Python, Java, Javascript, C++, Ruby on Rails',
    creator: alice
)

Intern.create!(
    biography: 'My name is Grant and I am searching for am AI internship for the opportunity to gain experience for future career opportunities',
    experience: '8 years as an intern at UMRF for the University of Memphis',
    field: 'AI',
    gpa: 3.99,
    readytowork: true,
    skill: 'Python, C++, C coding language, Ruby on Rails, Java',
    creator: alice
)

Intern.create!(
    biography: 'My name is Donte and I am searching for a data science internship in all states except Texas.',
    experience: 'Seventeen years as a data science developer at Fedex in Memphis',
    field: 'Data science',
    gpa: 4.00,
    readytowork: true,
    skill: 'Python, Ruby on Rails, SQL databases, data utilization, and machine learning and AI',
    creator: bob
)
Intern.create!(
    biography: 'My name is Julie and I am searching for a computer networking internship in order to maintin as much information as possible, so that I can start my own networking company.',
    experience: 'Four years as an intern at Computers and Networks Inc.  in Memphis',
    field: 'Network',
    gpa: 3.12,
    readytowork: true,
    skill: 'Python, Ruby on Rails, analytic skills, data utilization, Java',
    creator: bob
)

Business.create!(
    name: 'Hagerman and Company',
    biography: 'We are Hagarman and we offer a wide variety of professional services, including CAD training and support, consulting services, application health checks, document management implementations, and design automation consulting. We also  provide manufacturing consulting, industrial control panels and so much more.',
    field: 'Software Engineering',
    creator: bob
)

Business.create!(
    name: 'Intel',
    biography: 'Our team creates world-changing technology that improves the life of every person on the planet. Today we are applying oure reach, scale, and resources to enable our customers to capitalize more fully on the power of digital technology. We continously work to advance the design and manufacturing of semiconductors to help address the greatest challenges of our customers.',
    field: 'AI',
    creator: alice
)

Business.create!(
    name: 'Rockstar Games',
    biography: 'At Rockstar Games, we focus intently on quality and content to proudly produce exactly the kind of games we would want to play ourselves. A career at Rockstar Games is about passion and commitment, to the projects and to each other, all the while working on some of the most creatively rewarding and challenging projects to be found in any entertainment medium with some of the most talented people in the industry',
    field: 'Game Design',
    creator: alice
)

Business.create!(
    name: "Idealogic",
  biography: "We are Idealogic and have an extensive experience in creating high performance, feature-packed native and hybrid mobile application for all the major mobile platforms including iOS, Android and Windows Mobile",
  field: "Datascience",
  creator: bob
)

Business.create!(
    name: 'Twitter',
    biography: 'Here at the Twitter company, we are built on community. Together, we can be a force of good. We use the positive power of Twitter to strengthen our communities through our platform, people, and profits. ',
    field: 'Computer Networking',
    creator: alice
)

Review.create!(
    rating: 5,
    comment: 'Was a great worker! Got done 3 days earlier! I would definitely hire again!',
    creator: alice
)



work1 = Job.create!(
    name:  "web dev Job",
    exp_required: "5",
    job_field: "Web Dev",
    is_hiring: "True",
    desc: "We need someone to make a website for us.",
    creator: bob
)
work2 = Job.create!(
    name:  "ML Engineer wanted!",
    exp_required: "5",
    job_field: "AI",
    is_hiring: "True",
    desc: "Create an ML pipeline for predicting malicious activity",
    creator: bob
)

work3 = Job.create!(
    name:  "Full-Stack Intern Position",
    exp_required: "5",
    job_field: "SDE",
    is_hiring: "True",
    desc: "Full stack role",
    creator: bob
)
work4 = Job.create!(
    name:  "Front-end Intern Position",
    exp_required: "5",
    job_field: "SDE",
    is_hiring: "True",
    desc: "Front-end role",
    creator: bob
)


