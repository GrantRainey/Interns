class CreateJobs < ActiveRecord::Migration[7.0]
  def change
    create_table :jobs do |t|
      t.string :name
      t.string :exp_required
      t.string :job_field
      t.string :is_hiring
      t.string :desc

      t.timestamps
    end
  end
end
