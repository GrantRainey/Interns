Rails.application.routes.draw do
  resources :room_messages
  resources :rooms

 # root controller: :rooms, action: :index
  
  devise_for :users

  root to: redirect('/home')
  # Main Page Route?
  get 'home', to: 'jobs#home', as: 'home' #Put with jobs for simplicity.

  get 'jobs', to: 'jobs#index', as: 'jobs'
  post 'jobs', to: 'jobs#create'
  
  get 'jobs/new', to: 'jobs#new', as: 'new_job'
  get 'jobs/:id/edit', to: 'jobs#edit', as: 'edit_job'
  get 'jobs/:id', to: 'jobs#show', as: 'job'
  get 'jobs/:job_field/filter', to: 'jobs#filter', as: 'jobs_filter'
  get '/search/job', to: 'jobs#search', as: 'job_search'
  patch 'jobs/:id', to: 'jobs#update'
  delete 'jobs/:id', to: 'jobs#destroy'
  
  

  # Intern Routes
  get 'interns', to: 'interns#index', as: 'interns'
  post 'interns', to: 'interns#create'
  get 'interns/new', to: 'interns#new', as: 'new_intern'
  get 'interns/:id/edit', to: 'interns#edit', as: 'edit_intern'
  get 'intern/:id', to: 'interns#show', as: 'intern'
  get 'interns/:field', to: 'interns#filter', as: 'interns_filter'
  get '/search/intern', to: 'interns#search', as: 'intern_search'
  patch 'intern/:id', to: 'interns#update'
  delete 'intern/:id', to: 'interns#destroy'

  # Review Routes
  get 'users/:id/reviews', to: 'reviews#index', as: 'reviews'
  post 'users/:id/reviews', to: 'reviews#create'
  get 'users/:id/reviews/new', to: 'reviews#new', as: 'new_review'
  get 'users/:id/reviews/edit', to: 'reviews#edit', as: 'edit_review'
  get 'user/:id/reviews/:id', to: 'reviews#show', as: 'review'
  patch 'user/:id/reviews/:id', to: 'reviews#update'

  # Business Routes
  get 'businesses', to: 'businesses#index', as: 'businesses'
  post 'businesses', to: 'businesses#create'
  get 'businesses/new', to: 'businesses#new', as: 'new_business'
  get 'businesses/:id/edit', to: 'businesses#edit', as: 'edit_businesses'
  get 'business/:id', to: 'businesses#show', as: 'business'
  patch 'business/:id', to: 'businesses#update'
  delete 'business/:id', to: 'businesses#destroy'
end
