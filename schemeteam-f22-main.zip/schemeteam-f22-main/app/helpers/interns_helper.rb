module InternsHelper
end
