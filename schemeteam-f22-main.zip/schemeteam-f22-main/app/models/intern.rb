# == Schema Information
#
# Table name: interns
#
#  id          :bigint           not null, primary key
#  biography   :string
#  experience  :string
#  field       :string
#  gpa         :float
#  readytowork :boolean
#  skill       :string
#  created_at  :datetime         not null
#  updated_at  :datetime         not null
#
class Intern < ApplicationRecord
    belongs_to(
        :creator,
        class_name:  'User',
        foreign_key: 'user_id',
        inverse_of:  :interns
      ) 
end
