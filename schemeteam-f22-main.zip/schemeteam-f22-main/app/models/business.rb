# == Schema Information
#
# Table name: businesses
#
#  id         :bigint           not null, primary key
#  biography  :string
#  field      :string
#  name       :string
#  created_at :datetime         not null
#  updated_at :datetime         not null
#
class Business < ApplicationRecord
    belongs_to(
    :creator,
    class_name:  'User',
    foreign_key: 'user_id',
    inverse_of:  :businesses
    )
end
