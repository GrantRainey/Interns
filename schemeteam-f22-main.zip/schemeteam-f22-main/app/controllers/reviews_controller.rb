class ReviewsController < ApplicationController

    def new
        @review = Review.new
        render :new
    end

    def index
        @user = User.find(params[:id])
        @reviews = @user.reviews.all
        render :index
    end

    def create
        @user = User.find(params[:id])
        @review = @user.reviews.build(params.require(:review).permit(:rating, :comment))
        if @review.save
            flash[:success] = 'Review saved!'
            redirect_to reviews_path(@user.interns)
        else
            flash.now[:error] = 'Review not saved. Please try again.'
            render 'new', status: :unprocessable_entity
        end
    end
    
    def edit
        @user = User.find(params[:id])
        @review = @user.reviews.find(params[:id])
        render :edit
    end

    def update
        @user = User.find(params[:id])
        @review = @user.reviews.find(params[:id])
        if @review.update(params.require(:review).permit(:biography, :experience, :field, :gpa, :readytowork, :skill))
        flash[:success] = 'Review successfully updated!'
        redirect_to reviews_url(@review)
        else
        flash.now[:error] = 'Review update failed'
        render :edit, status: :unprocessable_entity
        end
    end

end
