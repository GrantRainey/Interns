class JobsController < ApplicationController
    def index
        @jobs = Job.all
        render :index
    end

    def filter
        @jobs = Job.where(job_field: params[:job_field])
        render :filter
    end

    def show
        @job = Job.find(params[:id])
        render :show
    end

    def new
        @job = Job.new
        render :new
    end

    def create
        @job = current_user.jobs.build(params.require(:job).permit(:name, :job_field, :is_hiring, :exp_required, :desc))
        if @job.save
            flash[:success] = 'Job was successfully created.'
            redirect_to jobs_url
        else
            flash.now[:error] = 'Unable to create Job.'
            render :new, status: :unprocessable_entity
        end
    end

    def edit
        @job = Job.find(params[:id])
        render :edit
    end

    def update
        @job = Job.find(params[:id])
        if @job.update(params.require(:job).permit(:name, :job_field, :desc, :exp_required, :is_hiring))
            flash[:success] = 'Job was successfully updated.'
            redirect_to job_path(@job)
        else
            flash.now[:error] = 'Unable to update Job.'
            render :edit, status: :unprocessable_entity
        end
    end

    def destroy
        @job = Job.find(params[:id])
        @job.destroy
        flash[:success] = 'Job was successfully destroyed.'
        redirect_to jobs_url
    end

    def require_permission
        if Job.find(params[:id]).creator != current_user
            flash[:error] = 'You do not have permission to do that.'
            redirect_to jobs_path(@job)
        end
    end

    def search
        if params[:search].blank?
            redirect_to(root_path, alert: "Empty search!") and return
        else
            @parameter = params[:search].downcase
            @results = Job.where("lower(name) LIKE :search", search: "%#{@parameter}%")
        end
    end

    def home
        @fields = Job.pluck(:job_field).uniq
        render :home
    end
    

    
end