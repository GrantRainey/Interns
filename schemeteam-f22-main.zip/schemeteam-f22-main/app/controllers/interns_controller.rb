class InternsController < ApplicationController
  def index
      @interns = Intern.all
      render :index
  end

  def filter
      @interns = Intern.where(field: params[:field])
      render :filter
  end

  def show
      @interns = Intern.find(params[:id])
      render :show
  end

  def new
      @intern = Intern.new
      render :new
  end

  def create
      @intern = current_user.interns.build(params.require(:intern).permit(:biography, :experience, :field, :gpa, :readytowork, :skill))
      if @intern.save
        flash[:success] = 'New Intern successfully added!'
        redirect_to interns_url
      else
        flash.now[:error] = 'Intern creation failed'
        render :new, status: :unprocessable_entity
      end
  end
    
  def edit
      @intern = Intern.find(params[:id])
      render :edit
  end

  def update
      @intern = Intern.find(params[:id])
      if @intern.update(params.require(:intern).permit(:biography, :experience, :field, :gpa, :readytowork, :skill))
        flash[:success] = 'Intern successfully updated!'
        redirect_to intern_url(@intern)
      else
        flash.now[:error] = 'Intern update failed'
        render :edit, status: :unprocessable_entity
      end
  end

  def destroy
      @intern = Intern.find(params[:id])
      @intern.destroy
      flash[:success] = 'This intern was successfully destroyed.'
      redirect_to interns_url, status: :see_other
  end

  def search
        if params[:search].blank?
            redirect_to(root_path, alert: "Empty search!") and return
        else
            @parameter = params[:search].downcase
            @results = Intern.where("lower(skill) LIKE :search", search: "%#{@parameter}%")
        end
  end

  def require_permission
    if Intern.find(params[:id]).creator != current_user
        flash[:error] = 'You do not have permission to do that.'
        redirect_to interns_path(@intern)
    end
  end
end
