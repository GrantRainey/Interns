class BusinessesController < ApplicationController

    def index
        @businesses = Business.all
        render :index
    end

    def show
        @businesses = Business.find(params[:id])
        render :show
    end
  
    def new
        @business = Business.new
        render :new
    end
  
    def create
        @business = current_user.businesses.build(params.require(:business).permit(:name, :biography, :field))
        if @business.save
          flash[:success] = 'New Business successfully added!'
          redirect_to businesses_url
        else
          flash.now[:error] = 'Business creation failed'
          render :new, status: :unprocessable_entity
        end
    end
      
    def edit
        @business = Business.find(params[:id])
        render :edit
    end
  
    def update
        @business = Business.find(params[:id])
        if @business.update(params.require(:business).permit(:name, :biography, :field))
          flash[:success] = 'Business successfully updated!'
          redirect_to businesses_url(@business)
        else
          flash.now[:error] = 'Business update failed'
          render :edit, status: :unprocessable_entity
        end
    end
  
    def destroy
        @business = Business.find(params[:id])
        @business.destroy
        flash[:success] = 'This intern was successfully destroyed.'
        redirect_to businesses_url, status: :see_other
    end
end
