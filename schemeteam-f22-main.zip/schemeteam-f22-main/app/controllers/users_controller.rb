class UsersController < ApplicationController

    def index
        @users = User.all
        render :index
    end
  
    def profile
        @users = User.find(params[:id])
        render :profile
    end
  
    def new
        @user = User.new
        render :new
    end

    def show
      @user = User.find(params[:id])
      render :show
  
    def create
        @user = current_user.users.build(params.require(:user).permit(:email, :fname, :lname))
        if @user.save
          flash[:success] = 'New user successfully added!'
          redirect_to users_url
        else
          flash.now[:error] = 'user creation failed'
          render :new, status: :unprocessable_entity
        end
    end
      
    def edit
        @user = User.find(params[:id])
        render :edit
    end
  
    def update
        @user = User.find(params[:id])
        if @user.update(params.require(:user).permit(:biography, :experience, :field, :gpa, :readytowork, :skill))
          flash[:success] = 'user successfully updated!'
          redirect_to user_url(@user)
        else
          flash.now[:error] = 'user update failed'
          render :edit, status: :unprocessable_entity
        end
    end
  
    def require_permission
      if User.find(params[:id]).creator != current_user
          flash[:error] = 'You do not have permission to do that.'
          redirect_to users_path(@user)
      end
    end
    
end
