# README

This README would normally document whatever steps are necessary to get the
application up and running.

Things you may want to cover:

* Ruby version

* System dependencies

* Configuration

* Database creation

* Database initialization

* How to run the test suite

* Services (job queues, cache servers, search engines, etc.)

* Deployment instructions

In order to run Cyber Jobs Chat Room, you must install Redis.

For Windows:
-  sudo apt-get update
-  sudo apt-get install redis
-  sudo service redis-server start


For Mac: 

-  brew install redis
-  redis-server

* ...
- Donte Mitchell (DKMTCL3@MEMPHIS.EDU)
- Jeffery Hubbart (jhhbbart@memphis.edu)
- Andre Brumfield (brmeld1@memphis.edu)
- Grant Rainey (gmrainey@memphis.edu)
