# == Schema Information
#
# Table name: businesses
#
#  id         :bigint           not null, primary key
#  biography  :string
#  field      :string
#  name       :string
#  created_at :datetime         not null
#  updated_at :datetime         not null
#
require "test_helper"

class BusinessTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
