# == Schema Information
#
# Table name: interns
#
#  id          :bigint           not null, primary key
#  biography   :string
#  experience  :string
#  field       :string
#  gpa         :float
#  readytowork :boolean
#  skill       :string
#  created_at  :datetime         not null
#  updated_at  :datetime         not null
#
require "test_helper"

class InternTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
