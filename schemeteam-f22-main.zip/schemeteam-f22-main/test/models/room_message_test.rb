require "test_helper"

class RoomMessageTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
